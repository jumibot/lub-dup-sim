from __future__ import annotations

"""Resonador (único) por stem.

Decisión de arquitectura:
- 1 Voice por Stem.
- 1 Resonator por Voice (no banco).

Implementación:
- Biquad band-pass (RBJ) "constant skirt gain, peak gain = Q".
- Direct Form I con estados (x1, x2, y1, y2).

Este resonador está adaptado de tu prototipo (heart_sounds.py), manteniendo
la misma fórmula de coeficientes y actualización de estado.

Contrato:
- `process()` sobrescribe `out`.
- No asigna memoria en tiempo de ejecución.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
import math
from typing import Optional, Sequence

from ..core.types import AudioBlock


@dataclass(frozen=True)
class ResonatorParams:
    """Parámetros del resonador.

    - f0_hz: frecuencia central
    - q: factor de calidad (relacionado con amortiguación/decay)
    - gain: ganancia aplicada a la salida del resonador
    """

    f0_hz: float
    q: float
    gain: float


class IResonator(ABC):
    """Contrato de resonador único.

    process() escribe 'out' (sobrescribe) y no asigna memoria.
    """

    @abstractmethod
    def reset(self) -> None: ...

    @abstractmethod
    def set_params(self, params: ResonatorParams) -> None: ...

    @abstractmethod
    def process(self, inp: Sequence[float], out: AudioBlock, n_frames: int) -> None: ...


class Resonator(IResonator):
    """Resonador biquad band-pass (2º orden).

    Basado en tu clase `Resonator` del prototipo:

        w0 = 2*pi*f0/fs
        alpha = sin(w0)/(2*Q)
        b = [alpha, 0, -alpha]
        a = [1+alpha, -2*cos(w0), 1-alpha]

    Se normaliza por a0 y se aplica DF1.

    Nota práctica:
    - Si no se han configurado params, la salida es 0.0.
    """

    def __init__(self, sample_rate_hz: float) -> None:
        fs = float(sample_rate_hz)
        if not (fs > 0.0):
            raise ValueError(f"sample_rate_hz inválido: {sample_rate_hz!r}")
        self._fs = fs

        self._params: Optional[ResonatorParams] = None

        # Estados DF1
        self._x1 = 0.0
        self._x2 = 0.0
        self._y1 = 0.0
        self._y2 = 0.0

        # Coefs normalizados (a0=1)
        self._b0 = 0.0
        self._b1 = 0.0
        self._b2 = 0.0
        self._a1 = 0.0
        self._a2 = 0.0

        self._gain = 1.0

    def reset(self) -> None:
        self._x1 = 0.0
        self._x2 = 0.0
        self._y1 = 0.0
        self._y2 = 0.0

    def set_params(self, params: ResonatorParams) -> None:
        self._params = params
        self._compute_coeffs(params)

    def _compute_coeffs(self, params: ResonatorParams) -> None:
        fs = self._fs
        nyq = 0.5 * fs

        f0 = float(params.f0_hz)
        q = float(params.q)
        self._gain = float(params.gain)

        # Sanitizado/clamps para evitar NaNs y divisiones raras
        f0 = max(1e-3, min(f0, nyq - 1e-3))
        q = max(q, 1e-6)

        w0 = 2.0 * math.pi * f0 / fs
        sin_w0 = math.sin(w0)
        cos_w0 = math.cos(w0)
        alpha = sin_w0 / (2.0 * q)

        # RBJ band-pass (constant skirt gain)
        b0 = alpha
        b1 = 0.0
        b2 = -alpha
        a0 = 1.0 + alpha
        a1 = -2.0 * cos_w0
        a2 = 1.0 - alpha

        inv_a0 = 1.0 / a0
        self._b0 = b0 * inv_a0
        self._b1 = b1 * inv_a0
        self._b2 = b2 * inv_a0
        self._a1 = a1 * inv_a0
        self._a2 = a2 * inv_a0

    def process(self, inp: Sequence[float], out: AudioBlock, n_frames: int) -> None:
        n = int(n_frames)

        if self._params is None:
            for i in range(n):
                out[i] = 0.0
            return

        b0, b1, b2 = self._b0, self._b1, self._b2
        a1, a2 = self._a1, self._a2
        x1, x2 = self._x1, self._x2
        y1, y2 = self._y1, self._y2
        g = self._gain

        for i in range(n):
            x0 = float(inp[i])
            y0 = (b0 * x0) + (b1 * x1) + (b2 * x2) - (a1 * y1) - (a2 * y2)

            x2, x1 = x1, x0
            y2, y1 = y1, y0

            out[i] = y0 * g

        self._x1, self._x2 = x1, x2
        self._y1, self._y2 = y1, y2
